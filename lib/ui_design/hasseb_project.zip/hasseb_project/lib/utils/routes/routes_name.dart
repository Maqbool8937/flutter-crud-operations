class RoutesName{
  static const String splashScreen='splash';
  static const String loginScreen='login';
  static const String signUpScreen='signUp';
  static const String forgotPasswordScreen='forgotPassword';

  //DashBoard Screen:
  static const String dashboardScreen='dashboard';


}